# ТехноСклад — склад компьютерной техники и комплектующих

Учебный Django-проект для ООО «ТехноСклад»: учёт товаров, клиентов и складских
заказов (приход/расход), аналитические отчёты и REST API с JWT-авторизацией.

## Стек

- Python 3.12, Django 5.1.4
- Django REST Framework 3.15.2 + SimpleJWT
- django-filter, django-cors-headers
- SQLite по умолчанию, PostgreSQL при заданном `POSTGRES_HOST`

## Быстрый старт

```powershell
$env:PYTHONPATH="C:\Users\Admin\Documents\deepseek-harness\default-workspace\_pkgs"
$env:PYTHONIOENCODING="utf-8"

python manage.py makemigrations
python manage.py migrate
python seed.py
python manage.py runserver 127.0.0.1:8021
```

Администратор: **admin / admin12345** (создаётся `seed.py`).

Демо-сотрудники: `keeper`, `mol`, `director` (пароль `tehnosklad12345`).

## Переменные окружения

Скопируйте `.env.example` в `.env` или задайте переменные в оболочке:

| Переменная | Назначение |
|---|---|
| `DJANGO_SECRET_KEY` | секретный ключ |
| `DJANGO_DEBUG` | `1` — режим отладки |
| `POSTGRES_HOST` | если пусто — SQLite, иначе PostgreSQL |
| `POSTGRES_PORT`, `POSTGRES_DB`, `POSTGRES_USER`, `POSTGRES_PASSWORD` | параметры PostgreSQL |

Проект не читает `.env` автоматически (дополнительных зависимостей нет) —
экспортируйте переменные средствами ОС или используйте `python-dotenv`.

## Структура

```
config/          настройки, корневые URL, WSGI/ASGI
apps/accounts/   сотрудники, JWT-аутентификация
apps/catalog/    категории, производители, склады, товары
apps/clients/    клиенты
apps/orders/     заказы (приход/расход), проведение и отмена
apps/reports/    сервис отчётов (без собственных моделей)
seed.py          идемпотентные демо-данные
```

## API

Все эндпоинты, кроме логина/обновления токена и корня `/api/`, требуют
заголовок `Authorization: Bearer <access>`.

### Аутентификация

| Метод | URL | Описание |
|---|---|---|
| POST | `/api/auth/login/` | `{"username": "...", "password": "..."}` → access/refresh + профиль |
| POST | `/api/auth/refresh/` | `{"refresh": "..."}` → новый access |
| GET | `/api/auth/me/` | профиль текущего сотрудника |

### Каталог и клиенты

| Метод | URL | Описание |
|---|---|---|
| GET/POST | `/api/products/` | список/создание товаров, фильтры `status`, `category`, `vendor`, `warehouse`, поиск `search`, сортировка `ordering` |
| GET/PUT/PATCH/DELETE | `/api/products/{id}/` | карточка товара |
| GET/POST | `/api/products/{id}/status/` | GET — статус, POST — пересчитать по остатку |
| GET | `/api/categories/`, `/api/vendors/`, `/api/warehouses/` | справочники |
| GET/POST | `/api/clients/` | клиенты, поиск по названию/телефону/email |
| GET/PUT/PATCH/DELETE | `/api/clients/{id}/` | карточка клиента |

### Заказы

| Метод | URL | Описание |
|---|---|---|
| GET/POST | `/api/orders/` | список/создание; фильтры `status`, `order_type`, `client`, `product`, даты |
| GET/PUT/PATCH/DELETE | `/api/orders/{id}/` | карточка заказа |
| POST | `/api/orders/{id}/complete/` | провести: приход +остаток, расход −остаток |
| POST | `/api/orders/{id}/cancel/` | отменить; завершённый заказ возвращает остатки |

### Отчёты

| Метод | URL | Описание |
|---|---|---|
| GET | `/api/reports/kpi/?days=30` | выручка, операции, средний чек, дефицит |
| GET | `/api/reports/movement/?days=30` | приход/расход по дням |
| GET | `/api/reports/top-products/?limit=5` | топ товаров по продажам |
| GET | `/api/reports/stock/` | сводка остатков и стоимость склада |

Пагинация — 20 записей на страницу (`?page=2`).

## Бизнес-логика

- `Order.save()` рассчитывает `total_amount = product.price × quantity`.
- `Order.complete()`: приход увеличивает остаток, расход уменьшает; расход не
  может увести остаток в минус; статус товара пересчитывается
  (`available` → `low` → `out`), фиксируется `completed_at`.
- `Order.cancel()`: отмена завершённого заказа возвращает остатки и пересчитывает
  статус товара.
- `Product.recalc_status()`: `0` — «Нет в наличии», `≤ min_quantity` —
  «Заканчивается», иначе — «В наличии».

## Админка

`http://127.0.0.1:8021/admin/` — заголовки «ТехноСклад: администрирование».
Товары редактируются списком (`quantity`, `status` — `list_editable`), у заказов
есть действия «Завершить выбранные заказы» и «Отменить выбранные заказы».

## Тесты

```powershell
python manage.py test
```

## PostgreSQL

Задайте `POSTGRES_HOST` (и при необходимости остальные `POSTGRES_*`) — настройки
автоматически переключатся на `django.db.backends.postgresql`. Без этой
переменной проект работает на SQLite и не требует установленного PostgreSQL.
