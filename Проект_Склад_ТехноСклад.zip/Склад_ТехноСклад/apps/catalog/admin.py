from django.contrib import admin

from .models import Category, Product, Vendor, Warehouse


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ("name", "slug")
    search_fields = ("name", "slug")
    prepopulated_fields = {"slug": ("name",)}


@admin.register(Vendor)
class VendorAdmin(admin.ModelAdmin):
    list_display = ("name", "country", "inn")
    search_fields = ("name", "country", "inn")


@admin.register(Warehouse)
class WarehouseAdmin(admin.ModelAdmin):
    list_display = ("name", "address")
    search_fields = ("name", "address")


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = (
        "name",
        "sku",
        "category",
        "vendor",
        "price",
        "quantity",
        "status",
    )
    list_editable = ("status", "quantity")
    list_filter = ("status", "category", "vendor", "warehouse")
    search_fields = ("name", "sku", "description")
    ordering = ("name",)
    list_per_page = 25
    readonly_fields = ("created_at",)
    fieldsets = (
        (None, {"fields": ("name", "sku", "description")}),
        ("Классификация", {"fields": ("category", "vendor", "warehouse")}),
        ("Складской учёт", {"fields": ("price", "quantity", "min_quantity", "status")}),
        ("Служебное", {"fields": ("created_at",)}),
    )
