from django.db import models
from django.urls import reverse


class Category(models.Model):
    """Категория техники или комплектующих."""

    name = models.CharField("Название", max_length=100, unique=True)
    slug = models.SlugField("Slug", max_length=100, unique=True)

    class Meta:
        verbose_name = "Категория"
        verbose_name_plural = "Категории"
        ordering = ["name"]

    def __str__(self):
        return self.name

    def get_absolute_url(self):
        return reverse("category-detail", args=[self.pk])


class Vendor(models.Model):
    """Производитель (вендор) техники."""

    name = models.CharField("Название", max_length=100, unique=True)
    country = models.CharField("Страна", max_length=60, blank=True)
    inn = models.CharField("ИНН", max_length=12, blank=True)

    class Meta:
        verbose_name = "Производитель"
        verbose_name_plural = "Производители"
        ordering = ["name"]

    def __str__(self):
        return self.name


class Warehouse(models.Model):
    """Склад компании."""

    name = models.CharField("Название", max_length=100)
    address = models.CharField("Адрес", max_length=255, blank=True)

    class Meta:
        verbose_name = "Склад"
        verbose_name_plural = "Склады"
        ordering = ["name"]

    def __str__(self):
        return self.name


class Product(models.Model):
    """Товар на складе."""

    class Status(models.TextChoices):
        AVAILABLE = "available", "В наличии"
        LOW = "low", "Заканчивается"
        OUT = "out", "Нет в наличии"

    name = models.CharField("Наименование", max_length=200)
    sku = models.CharField("Артикул", max_length=50, unique=True)
    category = models.ForeignKey(
        Category,
        on_delete=models.PROTECT,
        related_name="products",
        verbose_name="Категория",
    )
    vendor = models.ForeignKey(
        Vendor,
        on_delete=models.PROTECT,
        related_name="products",
        verbose_name="Производитель",
    )
    warehouse = models.ForeignKey(
        Warehouse,
        on_delete=models.PROTECT,
        related_name="products",
        verbose_name="Склад",
    )
    price = models.DecimalField("Цена", max_digits=12, decimal_places=2)
    quantity = models.PositiveIntegerField("Количество", default=0)
    min_quantity = models.PositiveIntegerField("Минимальный остаток", default=3)
    status = models.CharField(
        "Статус",
        max_length=20,
        choices=Status.choices,
        default=Status.AVAILABLE,
    )
    description = models.TextField("Описание", blank=True)
    created_at = models.DateTimeField("Создан", auto_now_add=True)

    class Meta:
        verbose_name = "Товар"
        verbose_name_plural = "Товары"
        ordering = ["name"]

    def __str__(self):
        return f"{self.name} ({self.sku})"

    @property
    def is_low(self):
        """Остаток на исходе: больше нуля, но не выше минимума."""
        return 0 < self.quantity <= self.min_quantity

    def recalc_status(self, save=True):
        """Пересчитать статус по остатку и (опционально) сохранить."""
        if self.quantity <= 0:
            new_status = self.Status.OUT
        elif self.quantity <= self.min_quantity:
            new_status = self.Status.LOW
        else:
            new_status = self.Status.AVAILABLE
        self.status = new_status
        if save and self.pk:
            self.save(update_fields=["status"])
        return new_status
