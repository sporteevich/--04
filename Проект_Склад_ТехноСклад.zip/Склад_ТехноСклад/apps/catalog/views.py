from rest_framework import viewsets
from rest_framework.decorators import action
from rest_framework.response import Response

from .models import Category, Product, Vendor, Warehouse
from .serializers import (
    CategorySerializer,
    ProductSerializer,
    ProductStatusSerializer,
    VendorSerializer,
    WarehouseSerializer,
)


class ProductViewSet(viewsets.ModelViewSet):
    """CRUD товаров, фильтры по статусу/категории и поиск."""

    queryset = Product.objects.select_related("category", "vendor", "warehouse")
    serializer_class = ProductSerializer
    filterset_fields = {
        "status": ["exact"],
        "category": ["exact"],
        "vendor": ["exact"],
        "warehouse": ["exact"],
    }
    search_fields = ("name", "sku", "description")
    ordering_fields = ("name", "price", "quantity", "created_at")
    ordering = ("name",)

    @action(detail=True, methods=["get", "post"], url_path="status")
    def status(self, request, pk=None):
        """GET — текущий статус товара, POST — пересчитать по остатку."""
        product = self.get_object()
        if request.method == "POST":
            product.recalc_status(save=True)
            product.refresh_from_db()
        return Response(ProductStatusSerializer(product).data)


class CategoryViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer
    search_fields = ("name",)
    ordering = ("name",)


class VendorViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = Vendor.objects.all()
    serializer_class = VendorSerializer
    search_fields = ("name", "country", "inn")
    ordering = ("name",)


class WarehouseViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = Warehouse.objects.all()
    serializer_class = WarehouseSerializer
    search_fields = ("name", "address")
    ordering = ("name",)
