﻿from decimal import Decimal

from django.core.exceptions import ValidationError
from django.test import TestCase

from apps.catalog.models import Category, Product, Vendor, Warehouse
from apps.clients.models import Client

from .models import Order


class OrderModelTests(TestCase):
    """Проверка расчётов и складских операций по заказам."""

    @classmethod
    def setUpTestData(cls):
        cls.category = Category.objects.create(name="Ноутбуки", slug="noutbuki")
        cls.vendor = Vendor.objects.create(name="ASUS", country="Тайвань")
        cls.warehouse = Warehouse.objects.create(name="Основной склад", address="Москва")
        cls.buyer = Client.objects.create(name="ООО «Ромашка»", phone="+7 900 000-00-01")

    def make_product(self, sku="NB-100", price="1000.00", quantity=10, min_quantity=3):
        return Product.objects.create(
            name=f"Товар {sku}",
            sku=sku,
            category=self.category,
            vendor=self.vendor,
            warehouse=self.warehouse,
            price=Decimal(price),
            quantity=quantity,
            min_quantity=min_quantity,
            status=Product.Status.AVAILABLE,
        )

    def make_order(self, product, quantity, order_type=Order.Type.OUTCOME):
        return Order.objects.create(
            client=self.buyer,
            product=product,
            quantity=quantity,
            order_type=order_type,
        )

    def test_total_amount_is_calculated_on_save(self):
        product = self.make_product(price="1250.50")
        order = self.make_order(product, 4)
        self.assertEqual(order.total_amount, Decimal("5002.00"))
        order.quantity = 2
        order.save()
        order.refresh_from_db()
        self.assertEqual(order.total_amount, Decimal("2501.00"))

    def test_income_complete_increases_stock(self):
        product = self.make_product(quantity=5)
        order = self.make_order(product, 4, order_type=Order.Type.INCOME)

        order.complete()

        product.refresh_from_db()
        order.refresh_from_db()
        self.assertEqual(product.quantity, 9)
        self.assertEqual(product.status, Product.Status.AVAILABLE)
        self.assertEqual(order.status, Order.Status.DONE)
        self.assertIsNotNone(order.completed_at)

    def test_outcome_complete_decreases_stock(self):
        product = self.make_product(quantity=10)
        order = self.make_order(product, 4, order_type=Order.Type.OUTCOME)

        order.complete()

        product.refresh_from_db()
        order.refresh_from_db()
        self.assertEqual(product.quantity, 6)
        self.assertEqual(product.status, Product.Status.AVAILABLE)
        self.assertEqual(order.status, Order.Status.DONE)

    def test_outcome_cannot_make_stock_negative(self):
        product = self.make_product(quantity=2)
        order = self.make_order(product, 5, order_type=Order.Type.OUTCOME)

        with self.assertRaises(ValidationError):
            order.complete()

        product.refresh_from_db()
        order.refresh_from_db()
        self.assertEqual(product.quantity, 2)
        self.assertEqual(order.status, Order.Status.NEW)
        self.assertIsNone(order.completed_at)

    def test_cancel_returns_stock_and_status(self):
        product = self.make_product(quantity=5, min_quantity=3)
        order = self.make_order(product, 4, order_type=Order.Type.OUTCOME)
        order.complete()

        product.refresh_from_db()
        self.assertEqual(product.quantity, 1)
        self.assertEqual(product.status, Product.Status.LOW)

        order.cancel()

        product.refresh_from_db()
        order.refresh_from_db()
        self.assertEqual(order.status, Order.Status.CANCELLED)
        self.assertIsNone(order.completed_at)
        self.assertEqual(product.quantity, 5)
        self.assertEqual(product.status, Product.Status.AVAILABLE)

    def test_partial_outcome_sets_low_status(self):
        product = self.make_product(quantity=5, min_quantity=3)
        order = self.make_order(product, 3, order_type=Order.Type.OUTCOME)

        order.complete()

        product.refresh_from_db()
        self.assertEqual(product.quantity, 2)
        self.assertEqual(product.status, Product.Status.LOW)
        self.assertTrue(product.is_low)

    def test_outcome_to_zero_sets_out_status(self):
        product = self.make_product(quantity=4, min_quantity=3)
        order = self.make_order(product, 4, order_type=Order.Type.OUTCOME)

        order.complete()

        product.refresh_from_db()
        self.assertEqual(product.quantity, 0)
        self.assertEqual(product.status, Product.Status.OUT)

