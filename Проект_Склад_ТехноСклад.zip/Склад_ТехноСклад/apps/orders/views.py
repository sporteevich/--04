from django.core.exceptions import ValidationError as DjangoValidationError
from rest_framework import status, viewsets
from rest_framework.decorators import action
from rest_framework.response import Response

from .models import Order
from .serializers import OrderSerializer


class OrderViewSet(viewsets.ModelViewSet):
    """CRUD заказов, проведение и отмена через отдельные действия."""

    queryset = Order.objects.select_related("client", "product", "product__vendor")
    serializer_class = OrderSerializer
    filterset_fields = {
        "status": ["exact"],
        "order_type": ["exact"],
        "client": ["exact"],
        "product": ["exact"],
        "created_at": ["date__gte", "date__lte"],
    }
    search_fields = ("client__name", "product__name", "product__sku", "comment")
    ordering_fields = ("created_at", "total_amount", "quantity")
    ordering = ("-created_at",)

    @action(detail=True, methods=["post"], url_path="complete")
    def complete(self, request, pk=None):
        """POST /api/orders/{id}/complete/ — провести заказ по складу."""
        order = self.get_object()
        try:
            order.complete()
        except DjangoValidationError as exc:
            return Response(
                {"detail": " ".join(exc.messages)}, status=status.HTTP_400_BAD_REQUEST
            )
        order.refresh_from_db()
        return Response(self.get_serializer(order).data)

    @action(detail=True, methods=["post"], url_path="cancel")
    def cancel(self, request, pk=None):
        """POST /api/orders/{id}/cancel/ — отменить заказ и вернуть остатки."""
        order = self.get_object()
        try:
            order.cancel()
        except DjangoValidationError as exc:
            return Response(
                {"detail": " ".join(exc.messages)}, status=status.HTTP_400_BAD_REQUEST
            )
        order.refresh_from_db()
        return Response(self.get_serializer(order).data)
