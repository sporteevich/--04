from django.contrib import admin, messages
from django.core.exceptions import ValidationError

from .models import Order


@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = (
        "id",
        "client",
        "product",
        "order_type",
        "quantity",
        "total_amount",
        "status",
        "created_at",
        "completed_at",
    )
    list_filter = ("status", "order_type", "created_at", "product__category")
    search_fields = ("client__name", "product__name", "product__sku", "comment")
    ordering = ("-created_at",)
    list_per_page = 25
    readonly_fields = ("total_amount", "created_at", "completed_at")
    date_hierarchy = "created_at"
    actions = ("complete_orders", "cancel_orders")

    @admin.action(description="Завершить выбранные заказы")
    def complete_orders(self, request, queryset):
        done, errors = 0, 0
        for order in queryset:
            try:
                if order.complete():
                    done += 1
            except ValidationError as exc:
                errors += 1
                self.message_user(
                    request,
                    f"Заказ №{order.pk}: {' '.join(exc.messages)}",
                    level=messages.ERROR,
                )
        self.message_user(
            request, f"Завершено заказов: {done}. Ошибок: {errors}.", level=messages.SUCCESS
        )

    @admin.action(description="Отменить выбранные заказы")
    def cancel_orders(self, request, queryset):
        cancelled, errors = 0, 0
        for order in queryset:
            try:
                if order.cancel():
                    cancelled += 1
            except ValidationError as exc:
                errors += 1
                self.message_user(
                    request,
                    f"Заказ №{order.pk}: {' '.join(exc.messages)}",
                    level=messages.ERROR,
                )
        self.message_user(
            request,
            f"Отменено заказов: {cancelled}. Ошибок: {errors}.",
            level=messages.SUCCESS,
        )
