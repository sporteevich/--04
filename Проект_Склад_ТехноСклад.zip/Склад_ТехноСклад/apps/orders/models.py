from decimal import Decimal

from django.core.exceptions import ValidationError
from django.db import models
from django.utils import timezone

from apps.catalog.models import Product
from apps.clients.models import Client


class Order(models.Model):
    """Складской заказ: приход или расход товара."""

    class Type(models.TextChoices):
        INCOME = "income", "Приход"
        OUTCOME = "outcome", "Расход"

    class Status(models.TextChoices):
        NEW = "new", "Новый"
        PROCESSING = "processing", "В работе"
        DONE = "done", "Завершён"
        CANCELLED = "cancelled", "Отменён"

    client = models.ForeignKey(
        Client,
        on_delete=models.CASCADE,
        related_name="orders",
        verbose_name="Клиент",
    )
    product = models.ForeignKey(
        Product,
        on_delete=models.PROTECT,
        related_name="orders",
        verbose_name="Товар",
    )
    quantity = models.PositiveIntegerField("Количество", default=1)
    order_type = models.CharField(
        "Тип заказа",
        max_length=20,
        choices=Type.choices,
        default=Type.OUTCOME,
    )
    status = models.CharField(
        "Статус",
        max_length=20,
        choices=Status.choices,
        default=Status.NEW,
    )
    total_amount = models.DecimalField(
        "Сумма",
        max_digits=12,
        decimal_places=2,
        default=Decimal("0.00"),
    )
    comment = models.TextField("Комментарий", blank=True)
    created_at = models.DateTimeField("Создан", auto_now_add=True)
    completed_at = models.DateTimeField("Завершён", null=True, blank=True)

    class Meta:
        verbose_name = "Заказ"
        verbose_name_plural = "Заказы"
        ordering = ["-created_at", "-id"]

    def __str__(self):
        return f"Заказ №{self.pk} — {self.product.name} ({self.get_order_type_display()})"

    def save(self, *args, **kwargs):
        """Сумма заказа всегда рассчитывается из цены товара и количества."""
        if self.product_id and self.quantity:
            self.total_amount = (self.product.price * self.quantity).quantize(
                Decimal("0.01")
            )
        super().save(*args, **kwargs)

    def complete(self):
        """Провести заказ по складу.

        Приход увеличивает остаток, расход уменьшает. Расход не может
        увести остаток в минус. После операции статус товара пересчитывается.
        """
        if self.status == self.Status.DONE:
            return False
        if self.status == self.Status.CANCELLED:
            raise ValidationError("Отменённый заказ нельзя завершить.")

        product = self.product
        if self.order_type == self.Type.INCOME:
            product.quantity += self.quantity
        else:
            if product.quantity < self.quantity:
                raise ValidationError(
                    f"Недостаточно товара «{product.name}» на складе: "
                    f"доступно {product.quantity}, требуется {self.quantity}."
                )
            product.quantity -= self.quantity

        product.recalc_status(save=False)
        product.save(update_fields=["quantity", "status"])

        self.status = self.Status.DONE
        self.completed_at = timezone.now()
        self.save(update_fields=["status", "completed_at"])
        return True

    def cancel(self):
        """Отменить заказ; завершённый заказ возвращает остатки на склад."""
        if self.status == self.Status.CANCELLED:
            return False

        if self.status == self.Status.DONE:
            product = self.product
            if self.order_type == self.Type.INCOME:
                if product.quantity < self.quantity:
                    raise ValidationError(
                        "Нельзя отменить приход: товар уже израсходован со склада."
                    )
                product.quantity -= self.quantity
            else:
                product.quantity += self.quantity
            product.recalc_status(save=False)
            product.save(update_fields=["quantity", "status"])

        self.status = self.Status.CANCELLED
        self.completed_at = None
        self.save(update_fields=["status", "completed_at"])
        return True
