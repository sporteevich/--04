from rest_framework import serializers

from .models import Order


class OrderSerializer(serializers.ModelSerializer):
    client_name = serializers.CharField(source="client.name", read_only=True)
    product_name = serializers.CharField(source="product.name", read_only=True)
    product_sku = serializers.CharField(source="product.sku", read_only=True)
    order_type_display = serializers.CharField(
        source="get_order_type_display", read_only=True
    )
    status_display = serializers.CharField(source="get_status_display", read_only=True)

    class Meta:
        model = Order
        fields = (
            "id",
            "client",
            "client_name",
            "product",
            "product_name",
            "product_sku",
            "quantity",
            "order_type",
            "order_type_display",
            "status",
            "status_display",
            "total_amount",
            "comment",
            "created_at",
            "completed_at",
        )
        read_only_fields = (
            "status",
            "total_amount",
            "created_at",
            "completed_at",
        )

    def validate_quantity(self, value):
        if value < 1:
            raise serializers.ValidationError("Количество должно быть больше нуля.")
        return value
