from django.urls import path

from .views import KPIView, MovementView, StockStatusView, TopProductsView

app_name = "reports"

urlpatterns = [
    path("kpi/", KPIView.as_view(), name="kpi"),
    path("movement/", MovementView.as_view(), name="movement"),
    path("top-products/", TopProductsView.as_view(), name="top-products"),
    path("stock/", StockStatusView.as_view(), name="stock"),
]
