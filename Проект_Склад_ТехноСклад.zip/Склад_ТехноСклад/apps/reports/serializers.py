from rest_framework import serializers


class ReportPeriodSerializer(serializers.Serializer):
    days = serializers.IntegerField(min_value=1, max_value=365, default=30)


class TopProductsQuerySerializer(serializers.Serializer):
    limit = serializers.IntegerField(min_value=1, max_value=50, default=5)


class KPISerializer(serializers.Serializer):
    revenue = serializers.DecimalField(max_digits=14, decimal_places=2)
    operations = serializers.IntegerField()
    avg_check = serializers.DecimalField(max_digits=14, decimal_places=2)
    low_stock = serializers.IntegerField()
    period_days = serializers.IntegerField()


class MovementRowSerializer(serializers.Serializer):
    date = serializers.DateField()
    income = serializers.IntegerField()
    outcome = serializers.IntegerField()
    operations = serializers.IntegerField()


class TopProductSerializer(serializers.Serializer):
    id = serializers.IntegerField()
    name = serializers.CharField()
    sku = serializers.CharField()
    sold = serializers.IntegerField()
    revenue = serializers.DecimalField(max_digits=14, decimal_places=2)


class StockStatusSerializer(serializers.Serializer):
    total = serializers.IntegerField()
    available = serializers.IntegerField()
    low = serializers.IntegerField()
    out = serializers.IntegerField()
    total_value = serializers.DecimalField(max_digits=16, decimal_places=2)
