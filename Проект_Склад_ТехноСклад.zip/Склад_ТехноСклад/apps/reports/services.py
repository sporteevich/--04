"""Сервис аналитических отчётов по складу."""
from datetime import timedelta
from decimal import Decimal

from django.db.models import Count, DecimalField, ExpressionWrapper, F, Sum
from django.db.models.functions import TruncDate
from django.utils import timezone

from apps.catalog.models import Product
from apps.orders.models import Order


class ReportService:
    """Расчёты для дашборда: KPI, движение, топ товаров, остатки."""

    @staticmethod
    def _since(days: int):
        return timezone.now() - timedelta(days=max(int(days), 1))

    @staticmethod
    def kpi(days: int = 30) -> dict:
        """Ключевые показатели за период."""
        days = max(int(days), 1)
        since = ReportService._since(days)
        done = Order.objects.filter(status=Order.Status.DONE, created_at__gte=since)

        operations = done.count()
        revenue = (
            done.filter(order_type=Order.Type.OUTCOME).aggregate(
                total=Sum("total_amount")
            )["total"]
            or Decimal("0.00")
        )
        avg_check = (
            (revenue / operations).quantize(Decimal("0.01"))
            if operations
            else Decimal("0.00")
        )
        low_stock = Product.objects.filter(
            quantity__lte=F("min_quantity")
        ).count()

        return {
            "revenue": revenue,
            "operations": operations,
            "avg_check": avg_check,
            "low_stock": low_stock,
            "period_days": days,
        }

    @staticmethod
    def movement_by_day(days: int = 30) -> list:
        """Приход и расход по дням (по завершённым заказам)."""
        days = max(int(days), 1)
        since = ReportService._since(days)
        rows = (
            Order.objects.filter(
                status=Order.Status.DONE,
                completed_at__isnull=False,
                completed_at__gte=since,
            )
            .annotate(day=TruncDate("completed_at"))
            .values("day", "order_type")
            .annotate(quantity=Sum("quantity"), operations=Count("id"))
            .order_by("day")
        )

        by_day = {}
        for row in rows:
            day = row["day"]
            bucket = by_day.setdefault(
                day, {"date": day, "income": 0, "outcome": 0, "operations": 0}
            )
            bucket[row["order_type"]] += row["quantity"] or 0
            bucket["operations"] += row["operations"] or 0

        return [by_day[day] for day in sorted(by_day)]

    @staticmethod
    def top_products(limit: int = 5) -> list:
        """Самые продаваемые товары (по завершённым расходам)."""
        limit = min(max(int(limit), 1), 50)
        rows = (
            Order.objects.filter(
                status=Order.Status.DONE,
                order_type=Order.Type.OUTCOME,
            )
            .values("product__id", "product__name", "product__sku")
            .annotate(sold=Sum("quantity"), revenue=Sum("total_amount"))
            .order_by("-sold", "product__name")[:limit]
        )
        return [
            {
                "id": row["product__id"],
                "name": row["product__name"],
                "sku": row["product__sku"],
                "sold": row["sold"] or 0,
                "revenue": row["revenue"] or Decimal("0.00"),
            }
            for row in rows
        ]

    @staticmethod
    def stock_status() -> dict:
        """Сводка остатков и стоимость склада."""
        total = Product.objects.count()
        available = Product.objects.filter(status=Product.Status.AVAILABLE).count()
        low = Product.objects.filter(status=Product.Status.LOW).count()
        out = Product.objects.filter(status=Product.Status.OUT).count()
        total_value = Product.objects.aggregate(
            value=Sum(
                ExpressionWrapper(
                    F("price") * F("quantity"),
                    output_field=DecimalField(max_digits=16, decimal_places=2),
                )
            )
        )["value"] or Decimal("0.00")

        return {
            "total": total,
            "available": available,
            "low": low,
            "out": out,
            "total_value": total_value,
        }
