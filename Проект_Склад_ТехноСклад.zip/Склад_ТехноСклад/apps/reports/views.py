from rest_framework.response import Response
from rest_framework.views import APIView

from .serializers import (
    KPISerializer,
    MovementRowSerializer,
    ReportPeriodSerializer,
    StockStatusSerializer,
    TopProductSerializer,
    TopProductsQuerySerializer,
)
from .services import ReportService


def _period_days(request):
    serializer = ReportPeriodSerializer(data=request.query_params)
    serializer.is_valid(raise_exception=True)
    return serializer.validated_data["days"]


class KPIView(APIView):
    """GET /api/reports/kpi/?days=30"""

    def get(self, request):
        data = ReportService.kpi(_period_days(request))
        return Response(KPISerializer(data).data)


class MovementView(APIView):
    """GET /api/reports/movement/?days=30"""

    def get(self, request):
        rows = ReportService.movement_by_day(_period_days(request))
        return Response(MovementRowSerializer(rows, many=True).data)


class TopProductsView(APIView):
    """GET /api/reports/top-products/?limit=5"""

    def get(self, request):
        serializer = TopProductsQuerySerializer(data=request.query_params)
        serializer.is_valid(raise_exception=True)
        rows = ReportService.top_products(serializer.validated_data["limit"])
        return Response(TopProductSerializer(rows, many=True).data)


class StockStatusView(APIView):
    """GET /api/reports/stock/"""

    def get(self, request):
        data = ReportService.stock_status()
        return Response(StockStatusSerializer(data).data)
