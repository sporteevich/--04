from decimal import Decimal

from django.test import TestCase

from apps.catalog.models import Category, Product, Vendor, Warehouse
from apps.clients.models import Client
from apps.orders.models import Order
from apps.reports.services import ReportService


class ReportServiceTests(TestCase):
    """Проверка аналитических отчётов."""

    @classmethod
    def setUpTestData(cls):
        category = Category.objects.create(name="Комплектующие", slug="komplektuyushchie")
        vendor = Vendor.objects.create(name="Intel", country="США")
        warehouse = Warehouse.objects.create(name="Основной склад", address="Москва")
        client = Client.objects.create(name="ООО «Вектор»", phone="+7 900 000-00-02")

        def product(sku, quantity, price="1000.00", status=Product.Status.AVAILABLE):
            return Product.objects.create(
                name=f"Товар {sku}",
                sku=sku,
                category=category,
                vendor=vendor,
                warehouse=warehouse,
                price=Decimal(price),
                quantity=quantity,
                min_quantity=3,
                status=status,
            )

        cls.product_a = product("A-1", 10)
        cls.product_b = product("B-1", 10)
        cls.product_low = product("C-1", 1, status=Product.Status.LOW)
        cls.product_out = product("D-1", 0, status=Product.Status.OUT)

        orders = [
            (cls.product_a, 2, Order.Type.OUTCOME),
            (cls.product_b, 3, Order.Type.OUTCOME),
            (cls.product_a, 5, Order.Type.INCOME),
        ]
        for prod, qty, order_type in orders:
            order = Order.objects.create(
                client=client,
                product=prod,
                quantity=qty,
                order_type=order_type,
            )
            order.complete()

        # Новый (незавершённый) заказ не должен попадать в KPI.
        Order.objects.create(
            client=client,
            product=cls.product_b,
            quantity=100,
            order_type=Order.Type.OUTCOME,
        )

    def test_kpi_counts_only_completed_operations(self):
        kpi = ReportService.kpi(days=30)
        self.assertEqual(kpi["operations"], 3)
        self.assertEqual(kpi["revenue"], Decimal("5000.00"))
        self.assertEqual(kpi["avg_check"], Decimal("1666.67"))
        self.assertEqual(kpi["low_stock"], 2)
        self.assertEqual(kpi["period_days"], 30)

    def test_movement_by_day_aggregates_income_and_outcome(self):
        movement = ReportService.movement_by_day(days=30)
        self.assertEqual(len(movement), 1)
        day = movement[0]
        self.assertEqual(day["income"], 5)
        self.assertEqual(day["outcome"], 5)
        self.assertEqual(day["operations"], 3)

    def test_top_products_orders_by_sold_quantity(self):
        top = ReportService.top_products(limit=2)
        self.assertEqual(len(top), 2)
        self.assertEqual(top[0]["sku"], "B-1")
        self.assertEqual(top[0]["sold"], 3)
        self.assertEqual(top[1]["sku"], "A-1")
        self.assertEqual(top[1]["sold"], 2)

    def test_stock_status_summary(self):
        stock = ReportService.stock_status()
        self.assertEqual(stock["total"], 4)
        self.assertEqual(stock["low"], 1)
        self.assertEqual(stock["out"], 1)
        self.assertEqual(stock["available"], 2)

        expected_value = sum(
            (p.price * p.quantity for p in Product.objects.all()),
            Decimal("0.00"),
        )
        self.assertEqual(stock["total_value"], expected_value)
