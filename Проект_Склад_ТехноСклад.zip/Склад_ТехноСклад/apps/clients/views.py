from rest_framework import viewsets

from .models import Client
from .serializers import ClientSerializer


class ClientViewSet(viewsets.ModelViewSet):
    """CRUD клиентов с поиском по названию, телефону и email."""

    queryset = Client.objects.select_related("manager")
    serializer_class = ClientSerializer
    filterset_fields = {"manager": ["exact"]}
    search_fields = ("name", "phone", "email", "inn", "contact_person")
    ordering_fields = ("name", "created_at")
    ordering = ("name",)
