from django.contrib import admin

from .models import Client


@admin.register(Client)
class ClientAdmin(admin.ModelAdmin):
    list_display = (
        "name",
        "phone",
        "email",
        "inn",
        "contact_person",
        "manager",
        "created_at",
    )
    list_filter = ("manager", "created_at")
    search_fields = ("name", "phone", "email", "inn", "contact_person")
    list_per_page = 25
    readonly_fields = ("created_at",)
