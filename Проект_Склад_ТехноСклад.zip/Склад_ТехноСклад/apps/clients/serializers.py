from rest_framework import serializers

from .models import Client


class ClientSerializer(serializers.ModelSerializer):
    manager_name = serializers.CharField(source="manager.full_name", read_only=True)

    class Meta:
        model = Client
        fields = (
            "id",
            "name",
            "phone",
            "email",
            "inn",
            "contact_person",
            "manager",
            "manager_name",
            "created_at",
        )
        read_only_fields = ("created_at", "manager_name")
