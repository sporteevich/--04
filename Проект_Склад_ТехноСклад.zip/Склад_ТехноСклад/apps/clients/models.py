from django.conf import settings
from django.db import models


class Client(models.Model):
    """Клиент компании (организация или ИП)."""

    name = models.CharField("Наименование", max_length=200)
    phone = models.CharField("Телефон", max_length=20, unique=True)
    email = models.EmailField("Email", blank=True)
    inn = models.CharField("ИНН", max_length=12, blank=True)
    contact_person = models.CharField("Контактное лицо", max_length=150, blank=True)
    manager = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="clients",
        verbose_name="Менеджер",
    )
    created_at = models.DateTimeField("Создан", auto_now_add=True)

    class Meta:
        verbose_name = "Клиент"
        verbose_name_plural = "Клиенты"
        ordering = ["name"]

    def __str__(self):
        return self.name
