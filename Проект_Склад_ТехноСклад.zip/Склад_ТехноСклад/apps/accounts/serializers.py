from rest_framework import serializers
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer

from .models import User


class UserSerializer(serializers.ModelSerializer):
    position_display = serializers.CharField(source="get_position_display", read_only=True)

    class Meta:
        model = User
        fields = (
            "id",
            "username",
            "full_name",
            "position",
            "position_display",
            "phone",
            "email",
            "is_staff",
        )
        read_only_fields = fields


class LoginSerializer(TokenObtainPairSerializer):
    """JWT-логин: в ответ дополнительно кладём данные сотрудника."""

    def validate(self, attrs):
        data = super().validate(attrs)
        data["user"] = UserSerializer(self.user).data
        return data
