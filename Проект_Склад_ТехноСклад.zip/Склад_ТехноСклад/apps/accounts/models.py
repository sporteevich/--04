from django.contrib.auth.models import AbstractUser
from django.db import models


class User(AbstractUser):
    """Сотрудник склада."""

    class Position(models.TextChoices):
        ADMIN = "admin", "Администратор"
        KEEPER = "keeper", "Кладовщик"
        MOL = "mol", "МОЛ"
        DIRECTOR = "director", "Директор"

    full_name = models.CharField("ФИО", max_length=150, blank=True)
    position = models.CharField(
        "Должность",
        max_length=20,
        choices=Position.choices,
        default=Position.KEEPER,
    )
    phone = models.CharField("Телефон", max_length=20, blank=True)

    class Meta:
        verbose_name = "Сотрудник"
        verbose_name_plural = "Сотрудники"
        ordering = ["username"]

    def __str__(self):
        return self.full_name or self.username
