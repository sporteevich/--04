from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin

from .models import User


@admin.register(User)
class UserAdmin(BaseUserAdmin):
    list_display = ("username", "full_name", "position", "phone", "is_staff", "is_active")
    list_filter = ("position", "is_staff", "is_superuser", "is_active")
    search_fields = ("username", "full_name", "phone", "email")
    fieldsets = BaseUserAdmin.fieldsets + (
        ("Сотрудник склада", {"fields": ("full_name", "position", "phone")}),
    )
    add_fieldsets = BaseUserAdmin.add_fieldsets + (
        ("Сотрудник склада", {"fields": ("full_name", "position", "phone")}),
    )
