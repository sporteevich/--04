"""Корневая маршрутизация проекта «ТехноСклад»."""
from django.contrib import admin
from django.urls import include, path
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny
from rest_framework.response import Response

admin.site.site_header = "ТехноСклад: администрирование"
admin.site.site_title = "ТехноСклад"
admin.site.index_title = "Управление складом компьютерной техники"


@api_view(["GET"])
@permission_classes([AllowAny])
def api_root(request):
    """Корень API: список доступных разделов."""
    return Response(
        {
            "service": "ТехноСклад API",
            "version": "1.0",
            "auth": {
                "login": "/api/auth/login/",
                "refresh": "/api/auth/refresh/",
                "me": "/api/auth/me/",
            },
            "catalog": {
                "products": "/api/products/",
                "categories": "/api/categories/",
                "vendors": "/api/vendors/",
                "warehouses": "/api/warehouses/",
            },
            "clients": "/api/clients/",
            "orders": "/api/orders/",
            "reports": {
                "kpi": "/api/reports/kpi/",
                "movement": "/api/reports/movement/",
                "top_products": "/api/reports/top-products/",
                "stock": "/api/reports/stock/",
            },
        }
    )


urlpatterns = [
    path("admin/", admin.site.urls),
    path("api/", api_root, name="api-root"),
    path("api/auth/", include("apps.accounts.urls")),
    path("api/", include("apps.catalog.urls")),
    path("api/", include("apps.clients.urls")),
    path("api/", include("apps.orders.urls")),
    path("api/reports/", include("apps.reports.urls")),
]
