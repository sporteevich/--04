"""Идемпотентное заполнение базы демонстрационными данными.

Запуск:  python seed.py
Суперпользователь: admin / admin12345
"""
import os
import sys
from decimal import Decimal
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE_DIR))
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings")

import django  # noqa: E402

django.setup()

from django.db import transaction  # noqa: E402

from apps.accounts.models import User  # noqa: E402
from apps.catalog.models import Category, Product, Vendor, Warehouse  # noqa: E402
from apps.clients.models import Client  # noqa: E402
from apps.orders.models import Order  # noqa: E402


def seed_users():
    admin, created = User.objects.get_or_create(
        username="admin",
        defaults={
            "full_name": "Администратор ТехноСклад",
            "position": User.Position.ADMIN,
            "phone": "+7 495 000-00-01",
            "email": "admin@tehnosklad.ru",
            "is_staff": True,
            "is_superuser": True,
        },
    )
    if created or not admin.check_password("admin12345"):
        admin.set_password("admin12345")
    admin.is_staff = True
    admin.is_superuser = True
    admin.position = User.Position.ADMIN
    admin.save()

    employees = [
        {
            "username": "keeper",
            "full_name": "Иванов Пётр Сергеевич",
            "position": User.Position.KEEPER,
            "phone": "+7 495 000-00-02",
            "email": "keeper@tehnosklad.ru",
        },
        {
            "username": "mol",
            "full_name": "Сидорова Анна Викторовна",
            "position": User.Position.MOL,
            "phone": "+7 495 000-00-03",
            "email": "mol@tehnosklad.ru",
        },
        {
            "username": "director",
            "full_name": "Кузнецов Дмитрий Александрович",
            "position": User.Position.DIRECTOR,
            "phone": "+7 495 000-00-04",
            "email": "director@tehnosklad.ru",
        },
    ]
    for data in employees:
        user, created = User.objects.get_or_create(
            username=data["username"], defaults=data
        )
        if created:
            user.set_password("tehnosklad12345")
            user.save()


def seed_catalog():
    categories = {
        "Ноутбуки": "noutbuki",
        "Комплектующие": "komplektuyushchie",
        "Периферия": "periferiya",
        "Сетевое оборудование": "setevoe-oborudovanie",
    }
    category_objs = {}
    for name, slug in categories.items():
        category_objs[name], _ = Category.objects.get_or_create(
            slug=slug, defaults={"name": name}
        )

    vendors = [
        {"name": "ASUS", "country": "Тайвань", "inn": "7712345678"},
        {"name": "Lenovo", "country": "Китай", "inn": "7712345679"},
        {"name": "HP", "country": "США", "inn": "7712345680"},
        {"name": "TP-Link", "country": "Китай", "inn": "7712345681"},
    ]
    vendor_objs = {}
    for data in vendors:
        vendor_objs[data["name"]], _ = Vendor.objects.get_or_create(
            name=data["name"], defaults=data
        )

    warehouses = [
        {"name": "Основной склад", "address": "г. Москва, ул. Складская, 12"},
        {"name": "Резервный склад", "address": "Московская обл., г. Химки, ул. Промышленная, 5"},
    ]
    warehouse_objs = {}
    for data in warehouses:
        warehouse_objs[data["name"]], _ = Warehouse.objects.get_or_create(
            name=data["name"], defaults=data
        )

    products = [
        {
            "name": "Ноутбук ASUS VivoBook 15",
            "sku": "NB-001",
            "category": "Ноутбуки",
            "vendor": "ASUS",
            "warehouse": "Основной склад",
            "price": "54990.00",
            "quantity": 12,
            "min_quantity": 3,
            "status": Product.Status.AVAILABLE,
            "description": "15,6\" FHD, Intel Core i5, 16 ГБ RAM, SSD 512 ГБ.",
        },
        {
            "name": "Ноутбук ASUS TUF Gaming F15",
            "sku": "NB-002",
            "category": "Ноутбуки",
            "vendor": "ASUS",
            "warehouse": "Основной склад",
            "price": "89990.00",
            "quantity": 4,
            "min_quantity": 3,
            "status": Product.Status.AVAILABLE,
            "description": "Игровой ноутбук, Intel Core i7, RTX 3050, 144 Гц.",
        },
        {
            "name": "Ноутбук Lenovo IdeaPad 3",
            "sku": "NB-003",
            "category": "Ноутбуки",
            "vendor": "Lenovo",
            "warehouse": "Основной склад",
            "price": "47990.00",
            "quantity": 7,
            "min_quantity": 3,
            "status": Product.Status.AVAILABLE,
            "description": "15,6\" FHD, AMD Ryzen 5, 8 ГБ RAM, SSD 256 ГБ.",
        },
        {
            "name": "Ноутбук HP Pavilion 14",
            "sku": "NB-004",
            "category": "Ноутбуки",
            "vendor": "HP",
            "warehouse": "Резервный склад",
            "price": "62990.00",
            "quantity": 2,
            "min_quantity": 3,
            "status": Product.Status.LOW,
            "description": "14\" FHD, Intel Core i5, 16 ГБ RAM, SSD 512 ГБ.",
        },
        {
            "name": "Материнская плата ASUS PRIME B660",
            "sku": "MB-001",
            "category": "Комплектующие",
            "vendor": "ASUS",
            "warehouse": "Основной склад",
            "price": "12990.00",
            "quantity": 9,
            "min_quantity": 3,
            "status": Product.Status.AVAILABLE,
            "description": "Socket LGA1700, DDR4, mATX.",
        },
        {
            "name": "SSD Lenovo SL700 512 ГБ",
            "sku": "SSD-001",
            "category": "Комплектующие",
            "vendor": "Lenovo",
            "warehouse": "Основной склад",
            "price": "4990.00",
            "quantity": 3,
            "min_quantity": 3,
            "status": Product.Status.LOW,
            "description": "SATA III, 2,5\", до 540 МБ/с.",
        },
        {
            "name": "Оперативная память HP 16 ГБ DDR4",
            "sku": "RAM-001",
            "category": "Комплектующие",
            "vendor": "HP",
            "warehouse": "Основной склад",
            "price": "6490.00",
            "quantity": 15,
            "min_quantity": 3,
            "status": Product.Status.AVAILABLE,
            "description": "DDR4-3200, 16 ГБ, DIMM.",
        },
        {
            "name": "Блок питания ASUS ROG 750W",
            "sku": "PSU-001",
            "category": "Комплектующие",
            "vendor": "ASUS",
            "warehouse": "Резервный склад",
            "price": "9990.00",
            "quantity": 0,
            "min_quantity": 3,
            "status": Product.Status.OUT,
            "description": "80+ Gold, модульный, 750 Вт.",
        },
        {
            "name": "Клавиатура Lenovo KB102",
            "sku": "KBD-001",
            "category": "Периферия",
            "vendor": "Lenovo",
            "warehouse": "Основной склад",
            "price": "1990.00",
            "quantity": 40,
            "min_quantity": 5,
            "status": Product.Status.AVAILABLE,
            "description": "Проводная, USB, раскладка RU.",
        },
        {
            "name": "Мышь HP X500",
            "sku": "MSE-001",
            "category": "Периферия",
            "vendor": "HP",
            "warehouse": "Основной склад",
            "price": "1490.00",
            "quantity": 35,
            "min_quantity": 5,
            "status": Product.Status.AVAILABLE,
            "description": "Оптическая, USB, 1600 dpi.",
        },
        {
            "name": "Роутер TP-Link Archer AX23",
            "sku": "NET-001",
            "category": "Сетевое оборудование",
            "vendor": "TP-Link",
            "warehouse": "Основной склад",
            "price": "5490.00",
            "quantity": 6,
            "min_quantity": 3,
            "status": Product.Status.AVAILABLE,
            "description": "Wi-Fi 6, AX1800, 4 порта Gigabit.",
        },
        {
            "name": "Коммутатор TP-Link TL-SG108",
            "sku": "NET-002",
            "category": "Сетевое оборудование",
            "vendor": "TP-Link",
            "warehouse": "Резервный склад",
            "price": "3290.00",
            "quantity": 0,
            "min_quantity": 3,
            "status": Product.Status.OUT,
            "description": "8 портов Gigabit, металлический корпус.",
        },
    ]
    product_objs = {}
    for data in products:
        defaults = dict(data)
        category = category_objs[defaults.pop("category")]
        vendor = vendor_objs[defaults.pop("vendor")]
        warehouse = warehouse_objs[defaults.pop("warehouse")]
        defaults["price"] = Decimal(defaults["price"])
        product_objs[data["sku"]], _ = Product.objects.get_or_create(
            sku=data["sku"],
            defaults={
                "category": category,
                "vendor": vendor,
                "warehouse": warehouse,
                **defaults,
            },
        )
    return product_objs


def seed_clients(users):
    manager = users.get("keeper")
    clients = [
        {
            "name": "ООО «Ромашка»",
            "phone": "+7 495 111-11-01",
            "email": "info@romashka.ru",
            "inn": "7701111111",
            "contact_person": "Петров Илья Николаевич",
        },
        {
            "name": "ООО «Вектор»",
            "phone": "+7 495 111-11-02",
            "email": "office@vektor.ru",
            "inn": "7702222222",
            "contact_person": "Смирнова Ольга Павловна",
        },
        {
            "name": "АО «СтройМаш»",
            "phone": "+7 495 111-11-03",
            "email": "buy@stroymash.ru",
            "inn": "7703333333",
            "contact_person": "Гусев Андрей Викторович",
        },
        {
            "name": "ИП Соколов А.В.",
            "phone": "+7 916 222-33-04",
            "email": "sokolov@mail.ru",
            "inn": "770444444444",
            "contact_person": "Соколов Алексей Владимирович",
        },
        {
            "name": "ООО «Офис-Плюс»",
            "phone": "+7 495 111-11-05",
            "email": "zakaz@office-plus.ru",
            "inn": "7705555555",
            "contact_person": "Морозова Елена Сергеевна",
        },
        {
            "name": "ООО «ТехноГрад»",
            "phone": "+7 495 111-11-06",
            "email": "it@technograd.ru",
            "inn": "7706666666",
            "contact_person": "Волков Максим Игоревич",
        },
    ]
    client_objs = {}
    for data in clients:
        client_objs[data["name"]], _ = Client.objects.get_or_create(
            phone=data["phone"],
            defaults={**data, "manager": manager},
        )
    return client_objs


def seed_orders(products, clients):
    by_sku = lambda sku: products[sku]  # noqa: E731
    by_name = lambda name: clients[name]  # noqa: E731

    orders = [
        # Завершённые заказы (5)
        {
            "comment": "SEED-01",
            "client": "ООО «Ромашка»",
            "product": "NB-001",
            "quantity": 2,
            "order_type": Order.Type.OUTCOME,
            "complete": True,
        },
        {
            "comment": "SEED-02",
            "client": "ООО «Вектор»",
            "product": "NB-003",
            "quantity": 1,
            "order_type": Order.Type.OUTCOME,
            "complete": True,
        },
        {
            "comment": "SEED-03",
            "client": "АО «СтройМаш»",
            "product": "KBD-001",
            "quantity": 5,
            "order_type": Order.Type.OUTCOME,
            "complete": True,
        },
        {
            "comment": "SEED-04",
            "client": "ИП Соколов А.В.",
            "product": "MSE-001",
            "quantity": 3,
            "order_type": Order.Type.OUTCOME,
            "complete": True,
        },
        {
            "comment": "SEED-05",
            "client": "ООО «Офис-Плюс»",
            "product": "RAM-001",
            "quantity": 5,
            "order_type": Order.Type.INCOME,
            "complete": True,
        },
        # Новые заказы (5)
        {
            "comment": "SEED-06",
            "client": "ООО «ТехноГрад»",
            "product": "NB-002",
            "quantity": 1,
            "order_type": Order.Type.OUTCOME,
            "complete": False,
        },
        {
            "comment": "SEED-07",
            "client": "ООО «Ромашка»",
            "product": "MB-001",
            "quantity": 4,
            "order_type": Order.Type.INCOME,
            "complete": False,
        },
        {
            "comment": "SEED-08",
            "client": "ООО «Вектор»",
            "product": "NET-001",
            "quantity": 2,
            "order_type": Order.Type.OUTCOME,
            "complete": False,
        },
        {
            "comment": "SEED-09",
            "client": "АО «СтройМаш»",
            "product": "SSD-001",
            "quantity": 10,
            "order_type": Order.Type.INCOME,
            "complete": False,
        },
        {
            "comment": "SEED-10",
            "client": "ИП Соколов А.В.",
            "product": "NB-001",
            "quantity": 3,
            "order_type": Order.Type.OUTCOME,
            "complete": False,
        },
    ]

    created_count = 0
    for data in orders:
        order, created = Order.objects.get_or_create(
            comment=data["comment"],
            defaults={
                "client": by_name(data["client"]),
                "product": by_sku(data["product"]),
                "quantity": data["quantity"],
                "order_type": data["order_type"],
                "status": Order.Status.NEW,
            },
        )
        if created:
            created_count += 1
            if data["complete"]:
                order.complete()
    return created_count


@transaction.atomic
def main():
    seed_users()
    products = seed_catalog()
    users = {
        user.username: user for user in User.objects.filter(
            username__in=["keeper", "mol", "director"]
        )
    }
    clients = seed_clients(users)
    created_orders = seed_orders(products, clients)

    for product in Product.objects.all():
        product.recalc_status(save=True)

    print("Демо-данные готовы:")
    print(f"  сотрудников: {User.objects.count()}")
    print(f"  категорий: {Category.objects.count()}")
    print(f"  производителей: {Vendor.objects.count()}")
    print(f"  складов: {Warehouse.objects.count()}")
    print(f"  товаров: {Product.objects.count()}")
    print(f"  клиентов: {Client.objects.count()}")
    print(f"  заказов: {Order.objects.count()} (создано сейчас: {created_orders})")
    print("  вход: admin / admin12345")


if __name__ == "__main__":
    main()
